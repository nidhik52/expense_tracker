//Expense tracker app using java used to add expenses and display them and store them in a CSV file.

package expense_tracker;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.util.Scanner;

public class ExpenseTracker {
	//Declaring private variables like amount, category and date.
	//Defining the Expense structure.
	private double amount;
	private String category;
	private String date;

	//Constructors - special method used to initialize objects.
	public ExpenseTracker(double amount, String category, String date) {
		this.amount = amount;
		this.category = category;
		this.date = date;
	}
	
	//Getters -  to get return the value from the objects.
	public double getAmount() { return amount; }
	public String getCategory() { return category; }
	public String getDate() { return date; }
	
	//To display expense details as a string @ Override.
	public String toString() {
		return amount + "," + category + "," + date;
	}
	
	//Methods for adding, viewing and storing expenses.
	private static void addExpense(Scanner scanner) throws IOException {
		//Adding the expense
		System.out.print("Enter expense amount: ");
		double amount = scanner.nextDouble();
		System.out.print("Enter expense category: ");
		String category = scanner.next();
		System.out.print("Enter date (YYYY-MM-DD): ");
		String date = scanner.next();
		
		ExpenseTracker expense = new ExpenseTracker(amount, category, date);
		
		//Saving the expense to a CSV file.
		FileWriter filewriter = new FileWriter("expenses.csv", true);
		filewriter.append(expense.toString().append("\n"));
		fileWriter.close();
		
		System.out.println("Expense added successfully!");
		
	}
	
	//Method to view all expenses.
	private static void viewExpenses() throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader("expenses.csv"));
		String line;
		System.out.println("Amount, Category, Date");
		while ((line = reader.readLine()) != null) {
			System.out.println(line);
		}
		reader.close();
	}
}

//Implementing the main menu.
public static void main(String[] args) throws IOException {
	initializeFile(); //Ensure the file is created.
    Scanner scanner = new Scanner(System.in);
    
    while (true) {
        System.out.println("1. Add Expense\n2. View Expenses\n3. Exit");
        int choice = scanner.nextInt();
        
        switch (choice) {
            case 1:
                addExpense(scanner);
                break;
            case 2:
                viewExpenses();
                break;
            case 3:
                System.out.println("Goodbye!");
                System.exit(0);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
    
 // Check if file exists, if not, create one
    private static void initializeFile() throws IOException {
        File file = new File("expenses.csv");
        if (!file.exists()) {
            file.createNewFile();
        }
    }

}





